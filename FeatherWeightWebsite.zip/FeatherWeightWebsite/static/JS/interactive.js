function FWclicked() {
	console.log("FW Clicked");
	var x = document.getElementById("fwNav");
	x.className = "active";
	console.log(x.className);
}

function HMclicked() {
	var x = document.getElementById("homeNav");
	x.className = "active";
	console.log("Home Clicked");
	console.log(x.className);
}